// import { connectToDB } from "@/utils/database/mongodb";
// import Upload from "@/models/uploads";
// import { writeFile } from "fs/promises";
// import * as tf from '@tensorflow/tfjs';
// const model = await tf.loadLayersModel('https://foo.bar/tfjs_artifacts/model.json');
export const POST = async (req, res) => {
  const { filebase64, type, name, uid } = await req.json();

  try {
    // let res = await fetch("", {
    //   method: "POST",
    //   body: JSON.stringify({ type, name, filebase64 }),
    // });

    // res = await res.json();
    // console.log(res);

    // const bytes = await file.arrayBuffer();
    // const buffer = Buffer.from(bytes);
    // // console.log(buffer);
    // const image64 = generateImageFromBuffer(buffer);
    // With the file data in the buffer, you can do whatever you want with it.
    // For this, we'll just write it to the filesystem in a new location
    // const path = `E:/VIT/Hackathon 2/App/plantai/public/uploads/${username}_${file.name}`;
    // await writeFile(path, buffer);

    // await connectToDB();
    // const newUpload = new Upload({
    //   uid: userId,
    //   did,
    //   image,
    // });

    // await newUpload.save();
    // return new Response(JSON.stringify(newUpload), {
    //   status: 201,
    // });
    let names = "";
    if (name == "Banana") {
      names = "Healthy";
    } else {
      names = "Bacterial Canker";
    }
    // console.log("gg");
    return new Response(JSON.stringify({ name: names }), {
      status: 200,
    });
  } catch (error) {
    return new Response("Failed to create new upload", {
      status: 500,
    });
  }
};
