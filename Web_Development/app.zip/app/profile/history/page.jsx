import React from "react";

const DiagnosisHistoryPage = () => {
  return <div>DiagnosisHistoryPage</div>;
};

export default DiagnosisHistoryPage;
