import React from 'react'

const PostsPage = () => {
  return (
    <div>PostsPage</div>
  )
}

export default PostsPage