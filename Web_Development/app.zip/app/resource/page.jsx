"use client";
import SearchBar from "@/components/SearchBar";
import { Card, Col, Row, Space } from "antd";
import Link from "next/link";
import React, { useEffect, useState } from "react";
const { Meta } = Card;
const ResourcePage = () => {
  const [disease, setDisease] = useState([]);
  useEffect(() => {
    const getDisease = async () => {
      try {
        let res = await fetch(`/api/admin/resource/diseaseslist`, {
          method: "POST",
        });
        res = await res.json();
        console.log(res);
        setDisease(res);
      } catch (error) {
        console.log(error);
      }
    };
    getDisease();
  }, []);

  const DiseaseCard = ({ value }) => {
    return (
      <Link href={`/resource/${value._id}`}>
        <Card
          hoverable
          style={{
            width: 240,
          }}
          cover={
            <img
              alt="example"
              height={250}
              width={200}
              src={value.image}
            />
          }
        >
          <Meta title={value.name} description={value.des} />
        </Card>
      </Link>
    );
  };
  return (
    <div>
      <section
        style={{
          borderRadius: "30px 30px 0px 0px",
          backgroundColor: "#FFFFFF",
        }}
      >
        <SearchBar />
      </section>
      <section
        style={{
          minHeight: "400px",
          padding: 40,
          borderRadius: "0px 0px 30px 30px",
          backgroundColor: "#FFFFFF",
        }}
      >
        <span style={{ fontSize: "34px", fontWeight: "bold" }}>
          Different Plant Diseases and their details
        </span>
        <br />

        <Row>
          {/* <DiseaseComp /> */}
          {disease.map((val, id) => {
            return (
              <Col key={id} style={{ margin: 20 }}>
                <DiseaseCard value={val} key={id} />
              </Col>
            );
          })}
        </Row>
      </section>
    </div>
  );
};

export default ResourcePage;
